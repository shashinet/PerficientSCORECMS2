//>>built
define("epi-find/nls/nl/ConfigModel",{"configErrorMessage":"Fout bij het lezen van de configuratie."});