﻿define("epi-find/configure/BoostingEditorModel", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/array",
    "dojo/when",
    "dojo/Deferred",
    "dojo/Stateful",

    "dojox/mvc/ModelRefController",
    "dojox/mvc/EditStoreRefController",
    "dojox/mvc/getPlainValue",

    "dojox/lang/functional",

    "epi-saas-base/mvc/_CommitReturnMixin",
    "epi-saas-base/mvc/_EmptiableRefControllerMixin",
    "epi-saas-base/RetryableXhrWrapper"
],
    function (declare,
              lang,
              array,
              when,
              Deferred,
              Stateful,
              ModelRefController,
              EditStoreRefController,
              getPlainValue,
              functional,
              _CommitReturnMixin,
              _EmptiableRefControllerMixin,
              RetryableXhrWrapper) {

        return declare([EditStoreRefController, _EmptiableRefControllerMixin, _CommitReturnMixin], {
            // summary:
            //      View model for Boosting Weights Editor widget.

            // weightsModel: ModelRefController
            //      Model controller for boosting weight properties
            weightsModel: null,

            // propertyNames: Array
            //      Names of the unified search object properties that can have a weight
            propertyNames: null,

            // defaultWeight: Integer
            //      Default weight value
            defaultWeight: 1,

            // invalidateCacheUrl: String
            //      URL of the endpoint to invalidate unified search weights cache.
            invalidateCacheUrl: null,

            set: function(/*String*/ name, /*Anything*/ value){
                // summary:
                //		Set a property to this. Overridden in order to reload weights from the new model.
                // name: String
                //		The property to set.
                // value: Anything
                //		The value to set in the property.

                this.inherited(arguments);
                if(name === this._refEditModelProp || name === this._refSourceModelProp){
                    this._refreshWeights(value);
                }
            },

            postscript: function() {
                this.inherited(arguments);
                this.weightsModel = new ModelRefController();
                this.set("emptyModel", new Stateful({
                    "name": "default",
                    "weights": {
                        "search_title": this.defaultWeight,
                        "search_text": this.defaultWeight,
                        "search_summary": this.defaultWeight,
                        "search_attachment": this.defaultWeight
                    },
                    tags: [ "searchtype:default" ]
                }));
                this.xhrHandler = new RetryableXhrWrapper();
            },

            refresh: function() {
                // summary:
                //      Loads first found unified search object. This method will be obsolete when objects are loaded by id.

                // TODO: temporary solution to load one item by id; it should be removed when user can select which search object is being edited
                var deferred = new Deferred();
                when(this.store.query({ tags: "searchtype:default" }), lang.hitch(this, function(results) {
                    var firstResult = results.length > 0 ? results[0] : null;
                    // To remove multiple boosting settings from the index, if there are such
                    if (results.length > 1) {
                        for(var i = 1; i < results.length; i++) {
                            this.store.remove(results[i].id);
                        }
                    }
                    if (!firstResult) {
                        // UnifiedSearch items are not found. Create and use new object with default weights.
                        this.empty();
                        deferred.resolve(this.get("model"));
                        return;
                    }
                    if (!firstResult.id) {
                        deferred.reject(new Error("Unable to load unified search object by id."));
                    }
                    when(this.getStore(firstResult.id), function(unifiedSearch) {
                        deferred.resolve(unifiedSearch);
                    }, function(error) {
                        deferred.reject(error);
                    });
                }), function (error) {
                    deferred.reject(error);
                });
                return deferred.promise;
            },

            commit: function () {
                return when(this.inherited(arguments), lang.hitch(this, function(weight) {
                    this._set("id", weight.id);
                    return this.invalidateCache();
                }));
            },

            setDefault: function () {
                // summary:
                //      Sets default values for weight properties.

                array.forEach(this.propertyNames, function(property){
                    this.weightsModel.set(property, this.defaultWeight);
                }, this);
            },

            hasControllerProperty: function(/*String*/ name){
                // summary:
                //		Returns true if this controller itself owns the given property.
                // name: String
                //		The property name.
                return this.inherited(arguments) || name === "weightsModel" || name === "propertyNames" || name === "defaultWeight";
            },

            invalidateCache: function () {
                return this.xhrHandler.xhr("POST", {
                    url: this.invalidateCacheUrl,
                    handleAs: "json"
                }).promise;
            },

            _refreshWeights: function(unifiedSearch) {
                if (!unifiedSearch) {
                    return;
                }
                this.propertyNames = functional.map(getPlainValue(unifiedSearch).weights, function (value, property) {
                    return property;
                });
                this.weightsModel.set("model", unifiedSearch.weights);
            }
        });
    });
