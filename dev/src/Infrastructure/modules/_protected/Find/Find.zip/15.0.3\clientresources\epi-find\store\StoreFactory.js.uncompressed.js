define("epi-find/store/StoreFactory", [
    "dojo/_base/config",
    "dojo/_base/declare",
    "dojo/_base/lang",

    "dojo/store/Memory",

    "epi/shell/store/Throttle",

    "./IdToNameResolvingMixin",
    "./ResourceQueryEngine",
    "./Elasticsearch",
    "./ResourceStore",
    "./BucketMixin",
    "./Statistics",
    "./Optimization",
    "./BestBets",
    "./SearchWithWeights",


    "./LangMixin",
    "./SiteMixin",

    "../AccessModel"
    ],
    function(
        config,
        declare,
        lang,

        Memory,

        Throttle,

        IdToNameResolvingMixin,
        ResourceQueryEngine,
        Elasticsearch,
        ResourceStore,
        BucketMixin,
        Statistics,
        Optimization,
        BestBets,
        SearchWithWeights,
        LangMixin,
        SiteMixin,

        AccessModel
        ) {

        var LangSiteMixin = declare([LangMixin, SiteMixin], {
            languageParameter: "tags",
            languagePrefix: "language:",

            siteParameter: "tags",
            sitePrefix: "siteid:",

            addToObject: true,
            addEmptyToQuery: false
        });

        var LangSiteMixinEmptyFilter = declare([LangSiteMixin], {
            emptyLanguage: "7D2DA0A9FC754533B091FA6886A51C0D",

            emptySite: "84BFAF5C52A349A0BC61A9FFB6983A66"
        });

        var ResourceStoreConfigured = declare([ResourceStore], {
            listProperty: "hits",
            itemProperty: "item"
        });


        var SynonymLangMixin = declare([LangMixin], {
            languageParameter: "tags",
            languagePrefix: "language:",
            emptyLanguage: "7D2DA0A9FC754533B091FA6886A51C0D"
        });

        // Add support for language and sites to some stores
        var StatisticsLangSiteStore = declare([Statistics, LangSiteMixin]),
            QueryLangSiteStore = declare([ResourceStoreConfigured, BucketMixin, LangSiteMixin]),
            TopHitStore = declare([StatisticsLangSiteStore, IdToNameResolvingMixin]),
            SynonymLangStore = declare([ResourceStoreConfigured, SynonymLangMixin]),
            BestBetStore = declare([BestBets, LangSiteMixinEmptyFilter]),
            OptimizationLangSiteStore = declare([Optimization, LangSiteMixinEmptyFilter]);


        var StoreFactory = declare(null, {
            authToken: null,

            createElasticSearchStore: function () {
                var esStore = new Elasticsearch({
                    target: config.find.serviceApiBaseUrl + "_search"
                });

                var throttledStore = Throttle(esStore, "query");
                throttledStore.unwrapped = esStore;
                return throttledStore;
            },

            createQueryStore: function () {
                return new QueryLangSiteStore({
                    target: config.find.serviceApiBaseUrl + "_stats/query"
                });
            },

            createTopQueryStore: function () {
                return new StatisticsLangSiteStore({
                    target: config.find.serviceApiBaseUrl + "_stats/query/top"
                });
            },

            createTopHitStore: function () {
                return new TopHitStore({
                    baseTarget: config.find.serviceApiBaseUrl,
                    target: config.find.serviceApiBaseUrl + "_stats/hit/top"
                });
            },

            createSynonymStore: function () {
                var synonymStore = AccessModel.access.view.synonyms.isEnabled() ?
                    new SynonymLangStore({
                        target: config.find.serviceApiBaseUrl + "_admin/synonym/",
                        idProperty: "id",
                        addToObject: true,
                        addEmptyToQuery: false
                    }) : new Memory({data: []});

                var throttledStore = Throttle(synonymStore, "query");
                throttledStore.unwrapped = synonymStore;
                return throttledStore;
            },

            createBestBetStore: function () {
                var bestBetStore = new BestBetStore({
                    target: config.find.siteServiceApiBaseUrl + "bestbets/",
                    idProperty: "id",
                    returnUpdatedItemFromPut: true,
                    queryEngine: ResourceQueryEngine,
                    handlerOptions: {authToken: this.authToken}
                });
                // Throttle prevents issuing several queries simultaneously,
                // which might cause UI glitches, like empty grid.
                var throttledStore = Throttle(bestBetStore, "query");
                throttledStore.unwrapped = bestBetStore;
                return throttledStore;
            },

            createRelatedQueriesStore: function () {
                var relatedQueriesStore = new OptimizationLangSiteStore({
                    target: config.find.serviceApiBaseUrl + "_didyoumean/",
                    queryEngine: ResourceQueryEngine
                });

                var throttledStore = Throttle(relatedQueriesStore, "query");
                throttledStore.unwrapped = relatedQueriesStore;
                return throttledStore;
            },

            createAutocompleteStore: function () {
                var autocompleteStore = new OptimizationLangSiteStore({
                    target: config.find.serviceApiBaseUrl + "_autocomplete/",
                    queryEngine: ResourceQueryEngine
                });

                var throttledStore = Throttle(autocompleteStore, "query");
                throttledStore.unwrapped = autocompleteStore;
                return throttledStore;

            },

            createConnectorStore: function () {
                return AccessModel.access.view.connectors.isEnabled() ?
                    new ResourceStoreConfigured({
                        target: config.find.serviceApiBaseUrl + "_admin/connector/",
                        idProperty: "id",
                        // queryEngine is required to workaround an issue with EditStoreRefController that calls
                        // store.put instead of store.add when a new item is created,
                        // which prevents Observable notifications.
                        queryEngine: ResourceQueryEngine
                    }) : new Memory({data: []});
            },

            createConnectorJobStore: function () {
                return AccessModel.access.view.connectors.isEnabled() ?
                    new ResourceStoreConfigured({
                        target: config.find.serviceApiBaseUrl + "_admin/connector_job/status/",
                        commandTarget: config.find.serviceApiBaseUrl + "_admin/connector_job/",
                        idProperty: "id",
                        _runCommand: function (id, command) {
                            var headers = lang.mixin({ Accept: this.accepts }, this.headers);
                            return this.xhrHandler.xhr("GET", {
                                url: this.commandTarget + command + "/" + id,
                                handleAs: "json",
                                headers: headers
                            });
                        },
                        start: function (id) {
                            return this._runCommand(id, "start");
                        },
                        stop: function (id) {
                            return this._runCommand(id, "stop");
                        }
                    }) : new Memory({data: []});
            },

            createBoostingStore: function () {
                return AccessModel.access.view.boosting.isEnabled() ?
                    new ResourceStoreConfigured({
                        target: config.find.serviceApiBaseUrl + "_admin/unifiedweights/",
                        idProperty: "id",
                        // queryEngine is required to workaround an issue with EditStoreRefController that calls
                        // store.put instead of store.add when a new item is created,
                        // which prevents Observable notifications.
                        queryEngine: ResourceQueryEngine
                    }) : new Memory({data: []});
            },

            createBoostingPreviewStore: function () {
                return AccessModel.access.view.boosting.isEnabled() ?
                    new SearchWithWeights({
                        target: config.find.siteServiceApiBaseUrl + "editorialboosting/searchwithweights/",
                        handlerOptions: {authToken: this.authToken}
                    }) :
                    new Memory({
                        data: [
                            {
                                "Title": "SEO Guide | EPiServer",
                                "Excerpt": "A guide to start optimizing content for search.",
                                "Url": "http://www.episerver.com/knowledge-base/eBooks/Why-SEO-Belongs-to-Content-Marketers/"
                            },
                            {
                                "Title": "SiteAttention for EPiServer Delivers On Improved Organic Search Results for Businesses  - EPiServer",
                                "Excerpt": "Search engine optimization (SEO) add-on uses Google Analytics to streamline creation of optimized content",
                                "Url": "http://www.episerver.com/about-us/pressroom/press-release-archive-2012/SiteAttention-for-EPiServer-Delivers-On-Improved-Organic-Search-Results-for-Businesses-/"
                            },
                            {
                                "Title": "Improve customer experience with effective onsite search - EPiServer",
                                "Excerpt": "When we talk about search, most marketers focus their energy and investment in optimizing content keywords and search engine ranking positions (SER...",
                                "Url": "http://www.episerver.com/about-us/our-blog/maria-wasing/How-to-improve-customer-experience-with-effective-onsite-search/"
                            },
                            {
                                "Title": "EPiServer Acquires On-Site Search Provider, Euroling",
                                "Excerpt": "EPiServer, a global software provider for innovative ecommerce and digital marketing solutions, today announced its acquisition of Swedish search p...",
                                "Url": "http://www.episerver.com/about-us/pressroom/pressreleases/EPiServer-Acquires-On-Site-Search-Provider-Euroling-/"
                            }
                        ],
                        idProperty: "Url",
                        query: function () {
                            return this.data;
                        }
                });
            },

            createStores: function () {
                // summary:
                //      Instantiate all stores
                config.dependencies["epi-find.ElasticsearchStore"] = this.createElasticSearchStore();
                config.dependencies["epi-find.QueryStore"] = this.createQueryStore();
                config.dependencies["epi-find.TopQueryStore"] = this.createTopQueryStore();
                config.dependencies["epi-find.TopHitStore"] = this.createTopHitStore();
                config.dependencies["epi-find.SynonymStore"] = this.createSynonymStore() ;
                config.dependencies["epi-find.BestBetStore"] = this.createBestBetStore();
                config.dependencies["epi-find.RelatedQueries"] = this.createRelatedQueriesStore();
                config.dependencies["epi-find.Autocomplete"] = this.createAutocompleteStore();
                config.dependencies["epi-find.ConnectorStore"] =this.createConnectorStore();
                config.dependencies["epi-find.ConnectorJobStore"] = this.createConnectorJobStore();
                config.dependencies["epi-find.BoostingStore"] = this.createBoostingStore();
                config.dependencies["epi-find.BoostingPreviewStore"] = this.createBoostingPreviewStore();
            }
        });

        return new StoreFactory();
    }
);
