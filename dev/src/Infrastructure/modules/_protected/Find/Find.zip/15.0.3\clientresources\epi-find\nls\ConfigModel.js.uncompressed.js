define("epi-find/nls/ConfigModel", { root: ({"configErrorMessage": "Error reading configuration."}),"da": true,
"de": true,
"es": true,
"fi": true,
"fr": true,
"it": true,
"ja": true,
"nl": true,
"no": true,
"sv": true,
"zh": true
});