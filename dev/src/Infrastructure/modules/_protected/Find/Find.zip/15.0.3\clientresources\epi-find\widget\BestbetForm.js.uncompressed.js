require({cache:{
'url:epi-find/widget/templates/BestbetForm.html':"<form data-dojo-attach-point='containerNode' data-dojo-attach-event='onreset:_onReset,onsubmit:_onSubmit' class='epi-formsWidgetWrapper'>\n    <ol class='epi-formsWidgetWrapper'>\n        <li data-dojo-type=\"epi-saas-base/form/FormListItem\" data-dojo-attach-point=\"bestBetPhraseListItem\">\n            <input id=\"bestbetPhrase\" name=\"phraseField\" data-dojo-attach-point=\"phraseField\" data-dojo-type=\"epi-find/widget/PhraseValidationTextBox\" data-dojo-props=\"required:true, phraseDelimiter:','\"/>\n        </li>\n\n        <li data-dojo-type=\"epi-saas-base/form/FormListItem\"  data-dojo-attach-point=\"targetContentListItem\">\n            <ol data-dojo-attach-point=\"targetContentInnerList\">\n                <li data-dojo-type=\"epi-saas-base/form/FormListItem\" class=\"epi-formsRow--inlineInputs--radio\" data-dojo-props=\"inputStyleType: 'inlineInputs'\">\n                    <input id=\"targetContentRadio\" data-dojo-attach-point=\"targetContentRadio\" data-dojo-type=\"dijit/form/RadioButton\" data-dojo-props=\"checked: true, value: '${CMS_SELECTOR_TYPE}'\" name=\"contentSelection\"/>\n                    <label for=\"targetContentRadio\" data-dojo-attach-point=\"targetContentRadioLabel\">${i18n.contentType_local}</label>\n                    <span id=\"bestbetTarget\" data-dojo-attach-point=\"cmsSelector\" data-dojo-type=\"epi-find/widget/CmsContentSelector\" data-dojo-props=\"required:true, repositoryKey: 'pages', searchArea: 'CMS/pages&files', allowedTypes: ['episerver.core.pagedata', 'episerver.core.icontentmedia'], showStatusIcon: true\"></span>\n                </li>\n                <li data-dojo-type=\"epi-saas-base/form/FormListItem\" data-dojo-attach-point=\"commerceSelectorListItem\" class=\"epi-formsRow--inlineInputs--radio\" data-dojo-props=\"inputStyleType: 'inlineInputs'\">\n                    <input id=\"commerceLinkRadio\" data-dojo-attach-point=\"commerceLinkRadio\" data-dojo-type=\"dijit/form/RadioButton\" data-dojo-props=\"value: '${COMMERCE_SELECTOR_TYPE}'\" name=\"contentSelection\"/>\n                    <label for=\"commerceLinkRadio\" data-dojo-attach-point=\"commerceLinkRadioLabel\" >${i18n.contentType_commerce}</label>\n                    <span id=\"bestbetCommerceTarget\" data-dojo-attach-point=\"commerceSelector\" data-dojo-type=\"epi-find/widget/CmsContentSelector\" data-dojo-props=\"required:true, repositoryKey: 'catalog', searchArea: 'Commerce/Catalog', allowedTypes: ['episerver.commerce.catalog.contenttypes.entrycontentbase', 'episerver.commerce.catalog.contenttypes.nodecontent'], showStatusIcon: true\"></span>\n                </li>\n                <li data-dojo-type=\"epi-saas-base/form/FormListItem\" class=\"epi-formsRow--inlineInputs--radio\" data-dojo-props=\"inputStyleType: 'inlineInputs'\">\n                    <input id=\"externalLinkRadio\" data-dojo-attach-point=\"externalLinkRadio\" data-dojo-type=\"dijit/form/RadioButton\" data-dojo-props=\"value: '${EXTERNAL_SELECTOR_TYPE}'\" name=\"contentSelection\"/>\n                    <label for = \"externalLinkRadio\" data-dojo-attach-point=\"externalLinkRadioLabel\" >${i18n.contentType_external}</label>\n                    <span class=\"epi-statusIndicatorIcon epi-no-background\"></span>\n                    <span class=\"epi-resourceInputContainer\">\n                       <input id=\"externalUrlTarget\" data-dojo-attach-point=\"externalUrl\" data-dojo-type=\"dijit/form/ValidationTextBox\" data-dojo-props=\"required:true, trim:true, pattern: this.urlRegex, intermediateChanges:true\" />\n                    </span>\n                </li>\n            </ol>\n        </li>\n\n        <li data-dojo-type=\"epi-saas-base/form/FormListItem\" data-dojo-attach-point=\"bestBetTitleListItem\">\n            <input id=\"bestbetTitle\" name=\"title\" data-dojo-attach-point=\"titleField\" data-dojo-type=\"epi-find/widget/TextBoxWithDefaultValue\" data-dojo-props=\"required:false, intermediateChanges:true\" />\n        </li>\n\n        <li data-dojo-type=\"epi-saas-base/form/FormListItem\" data-dojo-attach-point=\"inputIdListItem\">\n            <input id=\"bestbetDescription\" name=\"description\" data-dojo-attach-point=\"bestbetDescField\" data-dojo-type=\"epi-find/widget/ValidationTextAreaWithDefaultValue\" data-dojo-props=\"required:false, intermediateChanges:true\"/>\n        </li>\n\n        <li data-dojo-type=\"epi-saas-base/form/FormListItem\"  data-dojo-props=\"inputStyleType: ''\" data-dojo-attach-point=\"bestBetStyleListItem\" class=\"epi-formsRow--stacked-inputs--radio\">\n            <input id=\"bestbetStyleRadio\" data-dojo-attach-point=\"bestbetStyleRadio\" data-dojo-type=\"dijit/form/RadioButton\" data-dojo-props=\"checked: true \" name=\"bestbetStyle\"/>\n            <label for = \"bestbetStyleRadio\">${i18n.fields_bestbetStyleRadio1}</label><br />\n            <input id=\"resultStyleRadio2\" data-dojo-attach-point=\"resultStyleRadio\" data-dojo-type=\"dijit/form/RadioButton\" name=\"bestbetStyle\"/>\n            <label for = \"resultStyleRadio2\">${i18n.fields_bestbetStyleRadio2}</label>\n        </li>\n        <li data-dojo-type=\"epi-saas-base/form/FormListItem\" class=\"epi-formsRow--align-right\">\n            <input data-dojo-attach-point=\"submitButton\" type=\"submit\" data-dojo-type=\"dijit/form/Button\" class=\"epi-primary\" />\n            <input data-dojo-attach-point=\"resetButton\" type=\"reset\" data-dojo-type=\"dijit/form/Button\" />\n        </li>\n    </ol>\n</form>\n"}});
﻿define("epi-find/widget/BestbetForm", [
        "dojo/_base/array",
        "dojo/_base/declare",
        "dojo/_base/config",
        "dojo/_base/event",
        "dojo/_base/lang",
        "dojo/dom-construct",
        "dojo/topic",
        "dojo/when",

        "dojox/mvc/at",

        "dijit/form/Form",
        "dijit/_WidgetsInTemplateMixin",
        "dijit/registry",
        // widgets used in the template
        "dijit/form/Button",
        "dijit/form/ValidationTextBox",
        "dijit/form/RadioButton",
        "epi-saas-base/form/FormListItem",
        "./CmsContentSelector",
        "./ValidationTextAreaWithDefaultValue",
        "./TextBoxWithDefaultValue",
        "./TextAreaWithDefaultValue",
        "./PhraseValidationTextBox",

        "../ApplicationState",
        "epi-saas-base/widgets/_NotificationMixin",
        "epi-saas-base/UnicodeLetterRegexp",
        "epi-saas-base/UrlRegexp",
        "epi-saas-base/widgets/_ActionButtonsMixin",
        "../ConfigModel",

        "dojo/text!./templates/BestbetForm.html",
        "dojo/i18n!./nls/Bestbets"
    ],
    function(
        array,
        declare,
        config,
        event,
        lang,
        domConstruct,
        topic,
        when,

        at,

        Form,
        _WidgetsInTemplateMixin,
        registry,
        Button,
        ValidationTextBox,
        RadioButton,
        FormListItem,
        CmsContentSelector,
        Textarea,
        TextBoxWithDefaultValue,
        TextAreaWithDefaultValue,
        PhraseValidationTextBox,

        ApplicationState,
        _NotificationMixin,
        UnicodeLetterRegExp,
        UrlRegexp,
        _ActionButtonsMixin,
        ConfigModel,
        template,
        i18n
        ) {

        return declare([Form, _WidgetsInTemplateMixin, _NotificationMixin, _ActionButtonsMixin], {

            baseClass: "",
            ctrl: null,
            i18n: i18n,
            urlRegex: UrlRegexp,
            templateString: template,

            CMS_SELECTOR_TYPE: "PageBestBetSelector",
            COMMERCE_SELECTOR_TYPE: "CommerceBestBetSelector",
            EXTERNAL_SELECTOR_TYPE: "ExternalUrlBestBetSelector",

            postCreate: function() {
                this.inherited(arguments);
                this.bestBetPhraseListItem.set("label", i18n.fields_bestbetPhrase);
                this.bestBetPhraseListItem.set("description", i18n.separateMultiplePhrases);
                this.bestBetPhraseListItem.set("help", i18n.help_bestBetPhrase);
                this.targetContentListItem.set("help", i18n.help_targetField);
                this.targetContentListItem.set("label", i18n.fields_targetField);
                this.bestBetTitleListItem.set("label", i18n.fields_titleField);
                this.bestBetTitleListItem.set("help", i18n.help_titleField);
                this.inputIdListItem.set("label", i18n.fields_bestbetDescField);
                this.inputIdListItem.set("help", i18n.help_bestbetDescField);
                this.bestBetStyleListItem.set("help", i18n.help_bestbetStyleRadio);
                this.submitButton.set("label", i18n.addBestbet);
                this.resetButton.set("label", i18n.cancelBestbet);
                this.cmsSelector.set("title", i18n.contentType_select);
                this.commerceSelector.set("title", i18n.contentType_select);
            },

            startup:function() {
                this.inherited(arguments);

                var self = this, selectors = [{radio: this.targetContentRadio, selector: this.cmsSelector}];
                this.actionButtons = [this.submitButton, this.resetButton];
                this.enabledWhenNoChangesButtons = [this.resetButton];

                this.phraseField.set("value", at(this.ctrl, "phrases"));

                // Note: use double backslash \\ for one backslash \ in this regex (normal regex for a backslash is \\, but in this will need 4 times backslash \\\\)
                this.phraseField.set("pattern", "[^~`!@%^*()[\\]{}:;'|/<>?_-](?:"+UnicodeLetterRegExp+"|[0-9'&+#$_.,-\\s])*");
                this.phraseField.set("intermediateChanges", "true");

                this.cmsSelector.set("allowedTypes",  ["episerver.core.pagedata", "episerver.core.icontentmedia"]);
                this.cmsSelector.set("targetContent", at(this.ctrl, "target_key").transform({
                    format: function(value) {
                        var type = self.ctrl.get("target_type");
                        return self.isCMS(type) ? value : null;
                    },
                    parse: function(value) {
                        var type = self.ctrl.get("target_type");
                        return self.isCMS(type) ? value : self.ctrl.get("target_key"); // leave unchanged if external
                    }
                }));
                this.cmsSelector.set("rootPage", at(ApplicationState, "site")
                    .direction(at.from)
                    .transform({ format: function(site){
                        if (site) {
                            return site.rootPage;
                        }
                        return null;
                    }}));

                this.cmsSelector.set("selectedLang", at(ApplicationState, "language")
                    .direction(at.from)
                    .transform({ format: function(language){
                        if (language) {
                            return language.id;
                        }
                        return null;
                    }}));

                /*ApplicationState.set("language", language);*/
                if (ConfigModel.getValue("api.best_bets.external_content") === true) {
                    selectors.push({radio:this.externalLinkRadio, selector: this.externalUrl});
                    this.externalUrl.set("value",  at(this.ctrl, "target_key").transform({
                        format: function(value) {
                            var type = self.ctrl.get("target_type");
                            return self.isExternal(type) ? value : null;
                        },
                        parse: function(value) {
                            var type = self.ctrl.get("target_type");
                            return self.isExternal(type) ? value : self.ctrl.get("target_key"); // leave unchanged if not external
                        }
                    }));

                    if (ConfigModel.getValue("api.best_bets.commerce_content") === true &&
                        array.some(ConfigModel.getValue("api.best_bets.selector_types"), function (type) {
                            return self.COMMERCE_SELECTOR_TYPE === type;
                        })) {
                        selectors.push({ radio: this.commerceLinkRadio, selector: this.commerceSelector});

                        this.commerceSelector.set("allowedTypes",  ["episerver.commerce.catalog.contenttypes.entrycontentbase", "episerver.commerce.catalog.contenttypes.nodecontent"]);
                        this.commerceSelector.set("targetContent",  at(this.ctrl, "target_key").transform({
                            format: function(value) {
                                    var type = self.ctrl.get("target_type");
                                    return self.isCommerce(type) ? value : null;
                            },
                            parse: function(value) {
                                    var type = self.ctrl.get("target_type");
                                    return self.isCommerce(type) ? value : self.ctrl.get("target_key"); // leave unchanged if not external
                            }
                        }));


                        this.commerceSelector.set("selectedLang", at(ApplicationState, "language")
                            .direction(at.from)
                            .transform({ format: function(language){
                                if (language) {
                                    return language.id;
                                }
                                return null;
                            }}));
                    }
                    else {
                        this.commerceSelectorListItem.destroy();
                    }

                    this.own(
                        this.watch("value", function(name, oldValue, newValue) {
                            if (oldValue.contentSelection === newValue.contentSelection) {
                                return;
                            }
                            self.ctrl.set("target_type", newValue.contentSelection);
                        }),
                        this.ctrl.watch("target_type", function(name, oldValue, newValue) {
                            array.forEach(selectors, function(selector) {
                                if (selector.radio.value ==  newValue) {
                                    selector.radio.set("checked", true);
                                    selector.selector.set("disabled", false);
                                } else {
                                    selector.selector.reset();
                                    selector.selector.set("disabled", true);
                                }
                            });
                            self.titleField.set("required", self.isExternal( newValue));
                            self.bestbetDescField.set("required", self.isExternal( newValue));
                        })
                    );
                }
                else {
                    domConstruct.place(this.cmsSelector.domNode, this.targetContentListItem.wrapperNode, "first");
                    array.forEach(registry.findWidgets(this.targetContentInnerList), function(w) {
                        w.destroyRecursive();
                    });
                    domConstruct.destroy(this.targetContentInnerList);
                }

                if (ConfigModel.getValue("api.best_bets.get_indexed_data") === true) {
                    array.forEach(selectors, function(selector) {
                        if (!self.isExternal(selector.radio.value)) {
                            self.own(selector.selector.watch("targetContent", function(name, oldValue, newValue) {
                                if (newValue) {
                                    self.ctrl.store.query({targetKey:newValue}, {apiName:'GetIndexedData'}).forEach(lang.hitch(this, function(item) {
                                        if (newValue == selector.selector.get("targetContent")) { // to avoid slow updates from overwriting empty() during onReset()
                                            self.titleField.set("defaultValue", item.title || "");
                                            self.bestbetDescField.set("defaultValue", item.description || "");
                                        }
                                    }));
                                }
                                else {
                                    self.titleField.set("defaultValue", "");
                                    self.bestbetDescField.set("defaultValue", "");
                                }
                            }));
                        }
                    });
                }

                this.titleField.set("value", at(this.ctrl, "best_bet_target_title"));
                this.bestbetDescField.set("value", at(this.ctrl, "best_bet_target_description"));

                this.bestbetStyleRadio.set("name", "bestbetStyle");
                this.bestbetStyleRadio.set("checked", at(this.ctrl, "best_bet_has_own_style"));

                this.resultStyleRadio.set("name", "bestbetStyle");
                this.resultStyleRadio.set("checked", at(this.ctrl, "best_bet_has_own_style").transform({
                    format: function(value) {
                        return !value;
                    },
                    parse: function(value) {
                        return !value;
                    }
                }));

                this.reset();

                this.own(this.watchDataChanges(this.ctrl));
            },

            isExternal: function(targetType) {
                return targetType === this.EXTERNAL_SELECTOR_TYPE;
            },
            isCMS: function(targetType) {
                return targetType === this.CMS_SELECTOR_TYPE;
            },
            isCommerce: function(targetType) {
                return targetType === this.COMMERCE_SELECTOR_TYPE;
            },

            onSubmit: function (e) {
                var self = this;
                event.stop(e);
                if (!this.validate()) {
                    return ;
                }
                this.submitButton.focus();
                this.indicateInProgress(this.submitButton);
                when(this.ctrl.commit(),
                    function() {
                        self.reset();
                        self.showSuccess(i18n.savedMessage);
                        self.indicateSuccess();
                        topic.publish(config.intents.view.bestBets);
                        self.phraseField.focus();
                    },
                    function (error) {
                        self.showError(error, null, i18n.saveErrorTitle);
                        self.indicateError();
                    }
                );
            },

            onReset: function() {
                this.ctrl.reset();
                this.ctrl.empty();
                this.submitButton.set("label", i18n.addBestbet);
                return this.inherited(arguments);
            },

            edit: function(bestbetsID) {
                var self = this;
                if (this.editMode) {
                    this.reset();
                }
                when(this.ctrl.getStore(bestbetsID), function() {
                        self.phraseField.focus();
                        self.submitButton.set("label", i18n.saveBestbet);
                        self.set("hasChanges", false);
                    },
                    function (error) {
                        self.showError(error);
                    }
                );
            },

            submit: function() {
                // summary:
                //      pragmatically submit form if and only if the `onSubmit` returns true
                if (this.onSubmit() === false) {
                    return;
                }
                this.originalContainerNode.submit();
            }
        });

    });
