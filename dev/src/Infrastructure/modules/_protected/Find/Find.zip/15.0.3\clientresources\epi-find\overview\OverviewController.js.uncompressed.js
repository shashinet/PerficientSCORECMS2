define("epi-find/overview/OverviewController", [
    "dojo/_base/declare",
    "dojo/_base/config",

    "../_ControllerBase",
    "./OverviewModel",
    "./ExploreModel",
    "../widget/SwoshContainer",
    "../widget/_SwoshPaneBase",
    "../widget/_ActionableMixin",

    "../widget/Overview",
    "../widget/Explore"
],
function(
        declare,
        config,

        _ControllerBase,
        OverviewModel,
        ExploreModel,
        SwoshContainer,
        _SwoshPaneBase,
        _ActionableMixin,

        OverviewWidget,
        ExploreWidget
) {
    return declare([_ControllerBase, _ActionableMixin], {
        // summary: 
        //      Controller for Overview views.

        overviewModel: null,
        overviewWidget: null,
        exploreModel: null,
        exploreWidget: null,

        swoshContainer: null,

        startup: function() {
            if (this.isStarted()) {
                return;
            }
            this.inherited(arguments);

            this.overviewModel = new OverviewModel();
            this.own(this.overviewModel);
            this.overviewModel.init();
            this.exploreModel = new ExploreModel();
            this.own(this.exploreModel);
            this.exploreModel.init();

            var overview = this.overviewWidget = new OverviewWidget({
                    model: this.overviewModel
                }),
                explore = new ExploreWidget({
                    model: this.exploreModel
                }),

                overviewPane = new _SwoshPaneBase({
                    i18n: overview.i18n,
                    name: "overview",
                    location: "left"
                }),
                explorePane = new _SwoshPaneBase({
                    i18n: explore.i18n,
                    name: "explore",
                    location: "right"
                });

            overviewPane.addChild(overview);
            explorePane.addChild(explore);
            this.own(overview, overviewPane, explore, explorePane);

            this.registerAction(overviewPane.name, overview);
            this.registerAction(explorePane.name, explore);

            this.swoshContainer = new SwoshContainer({
                model: this.overviewModel,
                swoshPanes: [{
                    intent: config.intents.view.overview,
                    widget: overviewPane,
                    childWidget: overview
                }, {
                    intent: config.intents.view.explore,
                    widget: explorePane,
                    childWidget: explore
                }]
            });
            this.own(this.swoshContainer);

            this.currentAction = overview.name;
            this.previousActionFallback = true;
        },

        takeAction: function() {
            var activeWidget = this.inherited(arguments);
            
            for(var i in this.swoshContainer.swoshPanes) {
                var widget = this.swoshContainer.swoshPanes[i].childWidget;
                if (activeWidget === widget) {
                    this.swoshContainer.setActiveWidget(i);
                }
            }

            return activeWidget;
        },

        refresh: function() {
            this.overviewWidget.refresh();
        },

        show: function() {
            this._setupView([this.swoshContainer]);
        }
    });
});