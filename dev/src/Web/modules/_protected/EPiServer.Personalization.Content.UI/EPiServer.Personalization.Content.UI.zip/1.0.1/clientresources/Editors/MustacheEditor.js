define(
    [
        "dojo/_base/declare",
        "dojo/ready",
        "dojo/_base/lang",
        "dijit/_Widget",
        "dijit/_TemplatedMixin",
        "epi/dependency",
        "epi/shell/widget/_ValueRequiredMixin",
        "opti-recs/codemirror",
        "opti-recs/xml",
        "opti-recs/overlay",
        
        "xstyle/css!opti-recs/codemirror.css",
        "xstyle/css!opti-recs/editor.css",
    ],
    function (
        declare,
        ready,
        lang,
        _Widget,
        _TemplatedMixin,
        dependency,
        _ValueRequiredMixin,
        codemirror,
        xml,
        overlay,
        
    ) {
        return declare([_Widget, _TemplatedMixin, _ValueRequiredMixin],
            {
                templateString: '<div class="dijitInline"><textarea ' +
                    'spellcheck="false" ' +
                    'data-dojo-attach-point="code" ' +
                    'data-dojo-attach-event="onchange:_onChange"' +
                    '></textarea></div>',

                value: null,

                _editorValue: null,

                instance: null,

                editor: null,

                _setValueAttr: function (value) {
                    this._set('value', value || '');
                    if (this.code) {
                        this.code.value = this.value;
                    }
                    if (this.editor) {
                        this.editor.getDoc().setValue(this.value);
                    }
                },

                constructor: function () {
                    instance = this;
                    this.inherited(arguments);

                    ready(lang.hitch(this, function () {
                        codemirror.defineMode("mustache", function (config, parserConfig) {
                            var mustacheOverlay = {
                                token: function (stream, state) {
                                    var ch;
                                    if (stream.match("{{")) {
                                        while ((ch = stream.next()) != null)
                                            if (ch == "}" && stream.next() == "}") {
                                                stream.eat("}");
                                                return "mustache";
                                            }
                                    }
                                    while (stream.next() != null && !stream.match("{{", false)) { }
                                    return null;
                                }
                            };
                            return codemirror.overlayMode(codemirror.getMode(config, parserConfig.backdrop || "text/html"), mustacheOverlay);
                        });

                        this.set("_editorValue", this.value);
                        this.editor = codemirror.fromTextArea(this.domNode.children[0], { mode: "mustache" });
                        this.editor.setSize(700, 500);;
                        this.editor.on("change", this._onChange);
                    }));
                },
               
                _onChange: function (val) {
                    // summary:
                    //    Raised when the editor's content is changed.
                    //
                    // val:
                    //    The editor's changed value
                    //
                    // tags:
                    //    callback
                    var content = val.getValue();
                    instance._set("value", content);
                    instance.set("_editorValue", content);
                    if (instance.validate()) {
                        instance.onChange(content);
                    }
                },
            });
    });